# Point to calculate distance from
point <- function(x, p) {
    if (is.vector(p) && is.numeric(p[1]))
        point <- p else {
        if (p == "zero")
            point <- rep(0, ncol(x)) else if (p == "mean")
            point <- colMeans(x) else stop("Point must be either 'zero', 'mean' or a numerical vector")
    }
    return(point)
}

# Partitioning the variables
partition <- function(continuous, discrete, quantiles, names, type,
    block, point, method, p.minkowski,right) {
    # Set useful vectors
    Fx <- vector()
    # Set the block factor
    if (length(block) == nrow(continuous) & !is.factor(block))
        block <- as.factor(block)
    if (length(block) != nrow(continuous))
        block <- as.factor(rep("1", nrow(continuous)))
    # Concatenate the discrete variables
    if (!is.null(discrete))
        part <- as.factor(Reduce(function(...) paste(..., sep = "-"),
            data.frame(discrete, block))) else part <- block
    part <- droplevels(part)
    # Take the distances within the discrete variables
    if (method == "mahalanobis")
      dist <- MAHA(continuous,point,part)
    else
      dist <- distance(continuous,point,method,p.minkowski,part)
    # Discretize according to the quantiles inside each category of
    # the discrete variables
    for (j in levels(part)) {
      q <- quantile(dist[part == j], unique(quantiles), type = type,na.rm = TRUE)
      if(length(q) != length(unique(q)))
        q <- jitter(q,factor = 1e-05)
      breaks <- c(-Inf,q,Inf)
      Fx[part == j] <- as.character(cut(dist[part == j], breaks = breaks,
                                    labels = Reduce(function(...) paste(...,sep = "-"), unique(discrete[part == j]), names), include.lowest = TRUE,
                                    right = right))
    }
    return(as.factor(Fx))
}

# Mahalanobis distance inside each partition
MAHA <- function(data,p,part){
  if(ncol(data) == 1)
    return(as.vector(data[,1]))
  else{
    dist <- vector()
    part <- droplevels(part)
    for(j in levels(part)){
      x <- data[part == j,]
      if(nrow(x) > 1)
        dist[part == j] <- mahalanobis(x = x, center = point(x,p),cov = covp(x))
      else
        dist[part == j] <- dist(rbind.data.frame(point(x, p), x))[1]
    }
    return(dist)
  }
}

# Distances inside each partition
distance <- function(data,p,method,p.minkowski,part){
  if(ncol(data) == 1)
    return(as.vector(data[,1]))
  else{
    d <- vector()
    for(j in levels(part)){
      x <- data[part == j,]
      d[part == j] <- dist(rbind.data.frame(point(x, p), x), method = method,
                              p = p.minkowski)[1:nrow(x)]
    }
    return(d)
  }
}


# Lift function
lift <- function(Fx, Fy) {
     # Calculate the Lift table for two factor variables
     tmp <- prop.table(table(Fx, Fy))
     r <- rowSums(tmp)
     lift <- tmp/r
     rm(r)
     c <- colSums(tmp)
     lift <- t(t(lift)/c)
     rm(c)
     #lift <- cbind(lift,r)
     #lift <- rbind(lift,c(c,NA))
     #lift[nrow(lift),ncol(lift)] <- 1
     lift[is.nan(lift)] <- 0
     return(list("lift" = lift,"se" = NA,"cov" = NA))
}

#Lift function for table
 liftT <- function(table) {
   # Calculate the Lift given a contingency table
   tmp <- prop.table(table)
   r <- rowSums(tmp)
   lift <- tmp/r
   rm(r)
   c <- colSums(tmp)
   lift <- t(t(lift)/c)
   rm(c)
   #lift <- cbind(lift,r)
   #lift <- rbind(lift,c(c,NA))
   #lift[nrow(lift),ncol(lift)] <- 1
   #lift[is.nan(lift)] <- 0
   return(list("lift" = lift,"se" = NA,"cov" = NA))
 }

# Sample information
sinfo <- function(lift, sample, Fx, Fy,digits) {
    # Add sample information to the Lift Table
    if (sample %in% c("size", "joint")) {
      t <- table(Fx, Fy)
      if (sample == "joint")
          t <- signif(prop.table(t), digits)
      liftF <- data.frame()
      liftF <- data.frame(matrix(paste(signif(lift$lift, digits), " (", t, ")",sep = ""),
                                              nrow = nrow(t),ncol = ncol(t)),stringsAsFactors = FALSE)
      colnames(liftF) <- colnames(t)
      rownames(liftF) <- rownames(t)
      options(warn = -1)  #Supresse warning
      tmp <- addmargins(prop.table(table(Fx, Fy)))
      liftF[nrow(liftF) + 1, ] <- signif(tmp[nrow(tmp), ], digits)
      liftF[, ncol(liftF) + 1] <- signif(tmp[, ncol(tmp)], digits)
      options(warn = 0)
    }
    else if(sample == "se"){
      t <- table(Fx, Fy)
      liftF <- data.frame()
      liftF <- data.frame(matrix(paste(signif(lift$lift, digits), " (", signif(lift$se,digits), ")",sep = ""),
                                 nrow = nrow(t),ncol = ncol(t)),stringsAsFactors = FALSE)
      colnames(liftF) <- colnames(t)
      rownames(liftF) <- rownames(t)
      options(warn = -1)  #Supresse warning
      tmp <- addmargins(prop.table(table(Fx, Fy)))
      liftF[nrow(liftF) + 1, ] <- signif(tmp[nrow(tmp), ], digits)
      liftF[, ncol(liftF) + 1] <- signif(tmp[, ncol(tmp)], digits)
      options(warn = 0)
    } else if(sample == "none"){
      liftF <- signif(lift$lift, digits)
      options(warn = -1)  #Supresse warning
      tmp <- addmargins(prop.table(table(Fx, Fy)))
      liftF <- rbind(liftF,signif(tmp[nrow(tmp), ], digits))
      liftF <- cbind(liftF,signif(tmp[, ncol(tmp)], digits))
      options(warn = 0)
    }
    return(liftF)
}

# Sample information for table
sinfoT <- function(lift, sample, table,digits) {
  # Add sample information to the Lift Table
  if (sample %in% c("size", "joint")) {
    t <- table
    if (sample == "joint")
      t <- signif(prop.table(t), digits)
    liftF <- data.frame()
    liftF <- data.frame(matrix(paste(signif(lift$lift, digits), " (", t, ")",sep = ""),
                               nrow = nrow(t),ncol = ncol(t)),stringsAsFactors = FALSE)
    colnames(liftF) <- colnames(t)
    rownames(liftF) <- rownames(t)
    options(warn = -1)  #Supresse warning
    tmp <- addmargins(prop.table(t))
    liftF[nrow(liftF) + 1, ] <- signif(tmp[nrow(tmp), ], digits)
    liftF[, ncol(liftF) + 1] <- signif(tmp[, ncol(tmp)], digits)
    options(warn = 0)
  }
  else if(sample == "se"){
    t <- table
    liftF <- data.frame()
    liftF <- data.frame(matrix(paste(signif(lift$lift, digits), " (", signif(lift$se,digits), ")",sep = ""),
                               nrow = nrow(t),ncol = ncol(t)),stringsAsFactors = FALSE)
    colnames(liftF) <- colnames(t)
    rownames(liftF) <- rownames(t)
    options(warn = -1)  #Supresse warning
    tmp <- addmargins(prop.table(t))
    liftF[nrow(liftF) + 1, ] <- signif(tmp[nrow(tmp), ], digits)
    liftF[, ncol(liftF) + 1] <- signif(tmp[, ncol(tmp)], digits)
    options(warn = 0)
  }
  else if(sample == "none"){
    t <- table
    liftF <- signif(lift$lift, digits)
    options(warn = -1)  #Supresse warning
    tmp <- addmargins(prop.table(t))
    liftF <- cbind(liftF,signif(tmp[nrow(tmp), ], digits))
    liftF <- rbind(liftF,signif(tmp[, ncol(tmp)], digits))
    options(warn = 0)
  }
  return(liftF)
}

# Joint distribution
# joint <- function(lift) {
#     # Calculate the Joint Distribution form a Lift Table
#     joint <- matrix(nrow = nrow(lift) - 1, ncol = ncol(lift) - 1)
#     joint <- lift[-nrow(lift),-ncol(lift)] * lift[-nrow(lift),ncol(lift)]
#     joint <- t(t(joint) * lift[nrow(lift),-ncol(lift)])
#     return(joint)
# }

# Coeherent quantiles and names
quant.names <- function(quantiles, names) {
    # Test if the quantiles names match the quantiles
    if (length(names) != length(quantiles) + 1)
        stop("length(names) must equal length(quantiles) + 1.")
}

# Size of the data frames
sizedf <- function(x,y){
if(nrow(x) != nrow(y))
  stop("x and y must have the same number of rows.")
}

# Eta dependence measures with se
eta_se <- function(joint,w,windows,n) {
  # Calculate the Eta Dependence Measures from a Lift Table
  if(w){
    if(identical(x = windows,y = "all")){
      windows <- getPowSet(rownames(joint))
      windows[[1]] <- NULL
    }
    else if(identical(x = windows,y = "cat")){
      windows <- as.list(rownames(joint))
    }
    eta <- data.frame()
    for(s in 1:length(windows)){
      e <- se.eta(joint = joint,w = windows[[s]],n = n)
      eta <- rbind.data.frame(eta,data.frame("Window" = paste(windows[[s]],collapse = ""),"Eta" = e$eta,"se" = e$se))
    }
    return(eta)
  }
  else
    return(NA)
}

# Eta dependence measures withot se
eta <- function(joint,w,windows) {
  # Calculate the Eta Dependence Measures from a Lift Table
  if(w){
    if(identical(x = windows,y = "all")){
      windows <- getPowSet(rownames(joint)[-nrow(joint)])
      windows[[1]] <- NULL
    }
    else if(identical(x = windows,y = "cat")){
      windows <- as.list(rownames(joint)[-nrow(joint)])
    }
    eta <- data.frame()
    Ly <- log(joint[nrow(joint),-ncol(joint)]) # Log of Y probabilities
    Ly[is.infinite(Ly)] <- 0 # Y probabilities that equal zero
    for(s in 1:length(windows)){
      Jtmp <- rbind(joint[windows[[s]],]) # Joint distribution on W
      fYgivenX <- Jtmp[,-ncol(Jtmp)]/Jtmp[,ncol(Jtmp)] # Probability of Y given X in W
      Ltmp <- fYgivenX * t(kronecker(matrix(1,ncol = length(windows[[s]])),1/joint[nrow(joint),-ncol(joint)])) # Lift of Y and X in W
      LLtmp <- log(Ltmp) # Log lift
      LLtmp[is.infinite(LLtmp)] <- 0 # Log lift equals zero
      eta_tmp <- sum(Jtmp[,-ncol(Jtmp)] * LLtmp) # Part of eta
      eta_tmp <- - eta_tmp/sum(t(Jtmp[,-ncol(Jtmp)]) * Ly) # Eta
      eta <- rbind.data.frame(eta,data.frame("Window" = paste(windows[[s]],collapse = ""),"Eta" = eta_tmp,"se" = NA))
    }
    return(eta)
  }
  else
    return(NA)
}

# Mutual Information
mutual.info <- function(joint) {
  # Calculate the normalized Mutual information from a Joint Distribution
  fYgivenX <- joint/rowSums(joint) # Probability of Y given X in W
  lift <- fYgivenX*t(kronecker(matrix(1,ncol = nrow(joint)),1/colSums(joint))) # Lift of Y and X in W
  Llift <- log(lift) # Log lift
  Llift[is.infinite(Llift)] <- 0 # Log lift equals zero
  mutual <- sum(Llift * joint) # Part of eta
  Ly <- log(colSums(joint))
  Ly[is.infinite(Ly)] <- 0
  mutual <- - mutual/sum(colSums(joint) * Ly)
  return(mutual)
}

# Cleaning NA's on feature selection algorithm
cleanNA <- function(x, y) {
    # Clean the missing values from data frames
    ny <- rowSums(is.na(y))
    nx <- rowSums(is.na(x))
    x <- x[nx + ny == 0, ]
    y <- y[nx + ny == 0, ]
    p <- list(x, y)
    return(p)
}

# Powerset (Code by dpritch in a stackoverflow forum
# (http://stackoverflow.com/questions/18715580/algorithm-to-calculate-power-set-all-possible-subsets-of-a-set-in-r))
getPowSet <- function(set) {
    # Calculate the power set
    n <- length(set)
    keepBool <- sapply(2^(1:n - 1), function(k) rep(c(FALSE, TRUE),
        each = k, times = (2^n/(2 * k))))
    lapply(1:2^n, function(j) set[keepBool[j, ]])
}

# Singular matrix
is.singular <- function(x, setx) {
    # Determine if a matrix is singular
    detx <- det(x)
    return(abs(detx) < 1e-07)
}

# Singular covariance matrix
covp <- function(data) {
    # Determine if a covariance matrix is singular
    if (is.singular(cov(data))) {
        warning("a singular matrix was replaced by a diagonal matrix")
        return(diag(diag(cov(data))))
    } else return(cov(data))
}

# Assymptotic standar error for the Lift Function
se.lift <- function(joint,n){
  # Input is the estimated joint distribution without marginals and sample size
  c <- ncol(joint)
  l <- nrow(joint)
  theta <- matrix(t(joint),ncol = 1)
  theta[theta == 0] <- 10e-100
  Vtheta <- (1/n) * (diag(as.vector(theta)) - theta %*% t(theta))

  # Defing the matrices
  A <- rbind(diag(l*c),
             kronecker(diag(l),t(rep(1,c))),
             kronecker(t(rep(1,l)),diag(c)))
  B <- cbind(diag(l*c),
             -kronecker(diag(l),rep(1,c)),
             -kronecker(rep(1,l),diag(c)))

  # Lift function
  L <- exp(B %*% log(A %*% theta))

  # Variance matrix of lift function
  J <- diag(as.vector(exp(B %*% (log(A %*% theta))))) %*% B %*% (diag(1/as.vector(A %*% theta))) %*% A
  Vlift <- t(J) %*% Vtheta %*% J
  Vlift[matrix(t(joint),ncol = 1) == 0,] <- 0
  Vlift[,matrix(t(joint),ncol = 1) == 0] <- 0

  # Standard error
  SE <- t(matrix(sqrt(diag(Vlift)),nrow = c,ncol = l))
  SE[joint == 0] <- 0

  L <- t(matrix(L,nrow = c,ncol = l))
  L[joint == 0] <- 0
  rownames(L) <- rownames(joint)
  colnames(L) <- colnames(joint)
  return(list("lift" = L,"se" = SE,"cov" = Vlift))
}

# Standar error for the eta coefficient
se.eta <- function(joint,n,w){
  # Input is the estimated joint distribution without marginals, sample size and windows
  w <- c(1:length(rownames(joint)))[rownames(joint) %in% w]
  c <- ncol(joint)
  l <- nrow(joint)
  theta <- matrix(t(joint),ncol = 1)
  theta[theta == 0] <- 10e-100
  #Vtheta <- (1/n) * (diag(as.vector(theta)) - theta %*% t(theta))

  # Defing the matrices
  A <- rbind(diag(l*c),
             kronecker(diag(l),t(rep(1,c))),
             kronecker(t(rep(1,l)),diag(c)))
  B <- cbind(diag(l*c),
             -kronecker(diag(l),rep(1,c)),
             -kronecker(rep(1,l),diag(c)))
  C <- rbind(B,
             cbind(diag(c*l),matrix(0,nrow = l*c,ncol = c+l)),
             cbind(matrix(0,nrow = c,ncol = c*l+l),diag(c)))
  Delta <- matrix(0,nrow = length(w),ncol = l)
  for(i in 1:length(w))
    Delta[i,w[i]] <- 1
  D <- rbind(cbind(kronecker(Delta,diag(c)),matrix(0,nrow = c*length(w),ncol = c*l+c)),
             cbind(matrix(0,nrow = c*length(w),ncol = c*l),kronecker(Delta,diag(c)),matrix(0,nrow = c*length(w),ncol = c)),
             cbind(matrix(0,nrow = c,ncol = 2*c*l),diag(c)))
  H1 <- rbind(cbind(diag(c*length(w)),matrix(0,nrow = c*length(w),ncol = c*length(w) + c)),
              cbind(matrix(0,nrow = c,ncol = 2*c*length(w)),diag(c)))
  H2 <- rbind(matrix(0,nrow = c*length(w),ncol = 2*c*length(w)+c),
              cbind(matrix(0,nrow = c*length(w),ncol = c*length(w)),diag(c*length(w)),matrix(0,nrow = c*length(w),ncol = c)),
              matrix(0,nrow = c,ncol = 2*c*length(w) + c))
  H3 <- rbind(cbind(diag(c*length(w)),matrix(0,nrow = c*length(w),ncol = c)),
              matrix(0,nrow = c*length(w),ncol = c*length(w) + c),
              cbind(matrix(0,nrow = c,ncol = c*length(w)),diag(c)))
  M1 <- rbind(cbind(diag(c*length(w)),diag(c*length(w)),matrix(0,nrow = c*length(w),ncol = c)),
              cbind(matrix(0,nrow = c*length(w),ncol = c*length(w)),diag(c*length(w)),kronecker(matrix(1,nrow = length(w)),diag(c))))
  M3 <- cbind(1,-1)

  # Eta
  E <- D %*% exp(C %*% log( A %*% theta))
  K <- H3 %*% log(H1 %*% E) + H2 %*% E
  vec <- rep(1,nrow(K))
  vec[K[,1] < 0] <- -1
  M4 <- diag(vec)
  vec2 <- rep(-1,c*length(w))
  tmp <- K[c(1:(c*length(w))),]
  vec2[tmp >= 0] <- 1
  M2 <- rbind(c(vec2,rep(0,c*length(w))),c(rep(0,c*length(w)),rep(1,c*length(w))))
  eta <- exp(M3 %*% log(M2 %*% exp(M1 %*% log(M4 %*% K))))

  # Jacobian
  # X1 <- exp(M3 %*% exp(M2 %*% exp(M1 %*% log(M4 %*% K))))
  # X2 <- M3
  # X3 <- diag(as.vector(1/(M2 %*% exp(M1 %*% log(M4 %*% K)))))
  # X4 <- M2
  # X5 <- diag(as.vector(exp(M1 %*% log(M4 %*% K))))
  # X6 <- M1
  # X7 <- diag(as.vector(1/M4 %*% K))
  # X8 <- M4
  # X9 <- H3 %*% diag(as.vector(1/H1 %*% E)) %*% H1 + H2
  # X10 <- D
  # X11 <- diag(as.vector(exp(C %*% log(A %*% theta))))
  # X12 <- C
  # X13 <- diag(as.vector(1/A %*% theta))
  # X14 <- A
  #
  # # Jacobian
  # J <- X1 %*% X2 %*% X3 %*% X4 %*% X5 %*% X6 %*% X7 %*% X8 %*% X9 %*% X10 %*% X11 %*% X12 %*% X13 %*% X14

  # Variance
  #Veta <- J %*% Vtheta %*% t(J)

  # Se
  #se.eta <- sqrt(Veta)
  se.eta <- NA
  return(list("eta" = eta,"se" = se.eta))

}
