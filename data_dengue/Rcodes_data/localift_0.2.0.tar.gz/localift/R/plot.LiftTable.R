#' @export
#' @import reshape2
#' @import ggplot2
#' @import data.table
#' @title Plot a Lift Table
#'
#' @description  Plot the Lift Table between two groups of variables.
#'
#' @details If \emph{x} are \emph{y} are numeric vectors, it computes the Lift Table between
#'          the discrete random variables \emph{U} and \emph{V} determined from
#'          the sample quantiles of \emph{x} and \emph{y}, inside each level of the block variables. If \emph{x} or \emph{y}
#'          are numerical \emph{matrices}, then the Lift Table is computed from the discrete
#'          random variables \emph{U} and \emph{V} determined from the partition of \emph{(x,y)} by the selected distance method
#'          based on the sample quantiles, within each level of the block factors. If \emph{x} or \emph{y} are factor vectors,
#'          the Lift Function is calculated directly from \emph{x} and \emph{y}. If \emph{x} or \emph{y} contain numerical and factor variables
#'          then the discretization process is made by the quantile discretization of the sample distances from the given point, within
#'          each level of the factor and block variables.
#'
#'          If \emph{(U,V)} are discrete and \emph{(u,v)} is a category of \emph{(U,V)} then the Lift Function at such
#'          category is given by \eqn{L(u,v) = p(u,v) / (pU(u) * pV(v))} in which \emph{p} is
#'          the relative joint frequency of \emph{(U,V)} and \emph{pU} and \emph{pV}
#'          are the respective marginal relative frequencies. For more details see the References.
#'
#' @param table A contingency table without margins and with row and column names. Needed only if the factor variables are already tabulated.
#' @param x A numeric matrix, a factor vector or a numeric vector.
#' @param y A numeric matrix, a factor vector or a numeric vector.
#' @param x.lab Label of variable x.
#' @param y.lab Label of variable y.
#' @param block.x Block factor in which x must be discretize within. The quantiles will be taken inside each block.
#' @param block.y Block factor in which y must be discretize within. The quantiles will be taken inside each block.
#' @param quantilesx Quantiles in which the variable \emph{x} must be partitioned. Must not contain \emph{0} nor \emph{1}.
#' @param quantilesy Quantiles in which the variables \emph{y} must be partitioned. Must not contain \emph{0} nor \emph{1}.
#' @param quantile.type An integer between 1 and 9 selecting one of the nine quantile algorithms of the \link[stats]{quantile} function.
#' @param namesx Name of the partitions of \emph{x}. Its length must equal \emph{length(quantilesx) + 1}.
#' @param namesy Name of the partitions of \emph{y}. Its length must equal \emph{length(quantilesy) + 1}.
#' @param point.x Which point to calculate the distances of x from. Must be \emph{'zero'}, \emph{'mean'} for sample mean or
#'                a vector with the dimension of x.
#' @param point.y Which point to calculate the distances of y from. Must be \emph{'zero'}, \emph{'mean'} for sample mean or
#'                a vector with the dimension of y.
#' @param method Method that should be used to calculate the distance. Must be \emph{'mahalanobis'}, \emph{'euclidean'}, \emph{'maximum'},
#'               \emph{'manhattan'},\emph{'canberra'}, \emph{'binary'} or \emph{'minkowski'}.
#' @param p.minkowski The power of the Minkowski distance, if \emph{method = 'minkowski'}.
#' @param right Logical, indicating if the quantile intervals should be closed on the right (and open on the left) or vice versa.
#' @param digits Integer indicating the number of significant digits (signif) to be used on the Lift Table.
#' @return \item{ltable}{The Lift Table. Rows are related to \emph{x} and columns to \emph{y}.}
#' @examples
#' attach(requirement)
#' plot_LiftTable(x = SP,y = data.frame(C3,P1))
#' @references Simonis, A., Marcondes, D., Barrera, J. (2017) Feature Selection based on the Local Lift Dependence Scale. \emph{Submitted}

plot_LiftTable <- function(table = NULL,x, y,y.lab = "y",x.lab = "x",quantilesx = c(1/3,2/3),block.x = 1,block.y = 1,
                      namesx = c("1 TertileX", "2 TertileX", "3 TertileX"),quantilesy = c(1/3,2/3),
                      namesy = c("1 TertileY", "2 TertileY", "3 TertileY"),quantile.type = 7,point.x = "zero",
                      point.y = "zero",method = "mahalanobis", p.minkowski = 1,right = TRUE) {

  titles <- theme(strip.text = element_text(size = 12), axis.text = element_text(size = 12,
                                                                                 color = "black"),
                  axis.title = element_text(size = 16), legend.text = element_text(size = 14),
                  plot.title = element_text(size = 18,face = "bold"),
                  legend.title = element_text(size = 16,face = "bold"), panel.grid.major = element_blank(),
                  panel.grid.minor = element_blank(), panel.border = element_blank(),
                  panel.background = element_rect(fill="white",size=0.5, linetype="solid",color = "black"),
                  legend.background = element_rect(fill="white",size=0.5, linetype="solid",color = "black"),
                  legend.position="bottom",legend.spacing.x = unit(0.5, 'cm'))

  #LiftTable
  tab <- LiftTable(table = table,x = x,y = y,block.x = block.x,block.y = block.y,quantilesx = quantilesx,quantilesy = quantilesy,
                   namesx = namesx,namesy = namesy,point.x = point.x,point.y = point.y,quantile.type = quntile.type,method = method,
                   p.minkowski = p.minkowski,sample = "none",right = right,digits = 5)$ltable
  tab <- tab[-nrow(tab),-ncol(tab)]
  rnames <- rownames(tab)
  cnames <- colnames(tab)
  rownames(tab) <- seq(from = 0,to = -3*(nrow(tab)-1),by = -3)
  colnames(tab) <- seq(from = 0,to = -3*(ncol(tab)-1),by = -3)
  tab <- reshape2::melt(tab)
  tab$color[tab$value > 1.025] <- "+"
  tab$color[tab$value < 0.975] <- "-"
  tab$color[is.na(tab$color)] <- "="
  tab <- data.table(tab)
  tab <- tab[,value_max := max(value),by = Var1]
  tab <- tab[,value_min := min(value),by = Var1]
  tab$value_norm[tab$color == "-"] <- 1-tab$value_min[tab$color == "-"]
  tab$value_norm[tab$color == "+"] <- tab$value_max[tab$color == "+"]
  tab$value_norm[tab$color == "="] <- 1
  tab$value_norm[tab$color == "-"] <- (1-tab$value[tab$color == "-"])/tab$value_norm[tab$color == "-"]
  tab$value_norm[tab$color == "+"] <- tab$value[tab$color == "+"]/tab$value_norm[tab$color == "+"]
  tab$v_plot[tab$color == "+"] <- tab$Var1[tab$color == "+"] + tab$value_norm[tab$color == "+"]
  tab$v_plot[tab$color == "-"] <- tab$Var1[tab$color == "-"] - tab$value_norm[tab$color == "-"]
  tab$v_plot[tab$color == "="] <- tab$Var1[tab$color == "="]
  tab$text_pos[tab$color == "+"] <- tab$Var1[tab$color == "+"] + 1.25
  tab$text_pos[tab$color == "-"] <- tab$Var1[tab$color == "-"] - 1.25
  tab$text_pos[tab$color == "="] <- tab$Var1[tab$color == "="] + 0.5
  tab$lab[tab$value > 1.025] <- paste("+",round(100*(tab$value[tab$value > 1.025]-1)),"%",sep = "")
  tab$lab[tab$value < 0.975] <- paste("-",round(100*(1-tab$value[tab$value < 0.975])),"%",sep = "")
  tab$lab[is.na(tab$lab)] <- "Expected"

  #Plot
  tab$color <- factor(tab$color,c("-","=","+"))
  if(sum(c("-","=","+") %in% unique(tab$color)) == 3)
    col <- c("red","gray","green3")
  else if(sum(c("-","+") %in% unique(tab$color)) == 2)
    col <- c("red","green3")
  else if(sum(c("-","=") %in% unique(tab$color)) == 2)
    col <- c("red","gray")
  else if(sum(c("+","=") %in% unique(tab$color)) == 2)
    col <- c("gray","green3")
  p <- ggplot(tab) + theme_linedraw() + titles +
    geom_segment(mapping = aes(x = Var2,xend = Var2,y = Var1,yend = v_plot,colour = color), size = 2,
                 arrow = arrow(type = "closed",length = unit(0.4, "cm"))) +
    geom_hline(yintercept = unique(tab$Var1),linetype = "dashed") + ylab(x.lab) + xlab(y.lab) +
    scale_y_continuous(breaks = unique(tab$Var1),labels = rnames,limits = c(-3*(length(rnames)-1)-1.5,1.5)) +
    scale_x_continuous(breaks = unique(tab$Var2),labels = cnames) +
    scale_colour_manual("",values = col) +
    geom_text(aes(x = Var2,y = text_pos,label = lab,colour = color),size = 5) +
    theme(legend.position = "none")

  return(p)
}
