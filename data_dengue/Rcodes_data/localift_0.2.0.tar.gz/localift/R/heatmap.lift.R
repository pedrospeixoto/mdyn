#' @import ggplot2
#' @import MASS
#' @export
#' @title Lift Function Heatmap
#'
#' @description Heatmap of the Lift Function.
#'
#' @details Given two continuous random variables returns the heatmap of their estimated Lift Function. The heatmap
#'          paint the support of \emph{(x,y)} according to the values of the Lift Function
#'          \eqn{L(x,y) = f(x,y)/(g(x) * h(y))} in which \emph{f(x,y)} is the estimated joint density of \emph{(x,y)}
#'          and \emph{g(x)} and \emph{h(y)} are the respective estimated marginal distributions. If \eqn{L(x,y) > critical.value}
#'          then \emph{L(x,y) = critical.value}, i.e., \emph{L(x,y)} is truncated at \emph{critical.value}.
#'
#' @param x A vector of data.
#' @param y A vector of data.
#' @param xlab Label of the x-axis.
#' @param ylab Label of the y-axis.
#' @param palette The color palette to be used on the heatmap. Default is \emph{'Spectral'}.
#' @param na.color Color for \emph{NA} values.
#' @param contour Logical. Whether to plot the Lift Function contour.
#' @param contour.color Color of the Lift Function contour.
#' @param contour.alpha Transparency coefficient for the contour plot.
#' @param contour.bin Number of bins for the contour plot.
#' @param contour.binwidth Width of the bins for the contour plot.
#' @param critical.value Critical value in which the Lift Function must be truncated.
#' @param plot.title Title of the heatmap plot.
#' @param quantilesx Quantiles to be marked on the x-axis.
#' @param quantilesy Quantiles to be marked on the y-axis.
#' @param quantile.type An integer between 1 and 9 selecting one of the nine quantile algorithms of the \emph{quantile} function.
#' @param breaks Breaks of the heatmap legend. Must not contain \emph{0} nor \emph{critical.value} and all values
#'               must be less than the \emph{critical.value}.
#' @param n Number of equally spaced points at which the density is to be estimated. When n > 512, it is rounded up to a power of 2 during the calculations (as fft is used) and the final result is interpolated by approx. So it almost always makes sense to specify n as a power of two
#' @param grid Logical. Whether to plot grid lines representing the sample quantiles.
#' @return \item{plot}{A ggplot2 heatmap.}
#' @examples
#' attach(requirement)
#' heatmap.lift(SP,P2)
#'
#' @references Simonis, A., Marcondes, D., Barrera, J. (2017) Feature Selection based on the Local Lift Dependence Scale. \emph{Submitted}

heatmap.lift <- function(x, y, xlab = "x", ylab = "y", plot.title = " ",
    palette = "Spectral", na.color = "red", contour = TRUE, contour.color = "white",
    contour.alpha = 0.5, contour.bin = 15, contour.binwidth = 1, critical.value = 3,
    quantilesx = c(1/3, 2/3), quantilesy = c(1/3, 2/3), breaks = c(1,
        2), quantile.type = 7, n = length(x), grid = TRUE) {

    # Graphical parameters
    titles <- theme(strip.text = element_text(size = 12), axis.text = element_text(size = 10,
        color = "black"), axis.title = element_text(size = 12), legend.text = element_text(size = 10),
        legend.title = element_text(size = 12), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), panel.border = element_blank(),
        panel.background = element_blank())
    themes <- theme_linedraw()

    # Estimating densities
    dx <- density(x, n = n)
    fx <- approxfun(dx)

    dy <- density(y, n = n)
    fy <- approxfun(dy)

    kernel <- kde2d(x = x, y = y, n = n)

    # Lift function
    k <- 1
    x1 <- vector()
    y1 <- vector()
    lift <- vector()
    for (i in 1:nrow(kernel$z)) {
        for (j in 1:ncol(kernel$z)) {
            x1[k] <- kernel$x[i]
            y1[k] <- kernel$y[j]
            lift[k] <- kernel$z[i, j]/(fx(x1[k]) * fy(y1[k]))
            k <- k + 1
        }
    }
    lift[lift > critical.value] <- critical.value
    pdata <- data.frame(x1, y1, lift)

    # Plot
    if (contour == TRUE)
        plot <- {
            ggplot(pdata) + themes + titles + aes(x = x1, y = y1,
                z = lift, fill = lift) + geom_tile() + ggtitle(plot.title) +
                coord_equal() + geom_contour(colour = contour.color,
                alpha = contour.alpha, bins = contour.bin, binwidth = contour.binwidth) +
                scale_fill_distiller("Lift Function", palette = palette,
                  na.value = na.color, limits = c(round(min(pdata$lift,
                    na.rm = TRUE)), round(max(pdata$lift, na.rm = TRUE))),
                  breaks = c(0, breaks, critical.value), labels = c(0,
                    breaks, paste(">=", critical.value))) + xlab(xlab) +
                ylab(ylab)
        } else {
        plot <- {
            ggplot(pdata) + themes + titles + aes(x = x1, y = y1,
                z = lift, fill = lift) + geom_tile() + ggtitle(plot.title) +
                coord_equal() + scale_fill_distiller("Lift Function",
                palette = palette, na.value = na.color, limits = c(round(min(pdata$lift,
                  na.rm = TRUE)), round(max(pdata$lift, na.rm = TRUE))),
                breaks = c(0, breaks, critical.value), labels = c(0,
                  breaks, paste(">=", critical.value))) + xlab(xlab) +
                ylab(ylab)
        }
    }
    if (grid)
        plot <- {
            plot + geom_vline(xintercept = quantile(x, c(0, quantilesx,
                1), type = quantile.type)) + geom_hline(yintercept = quantile(y,
                c(0, quantilesy, 1), type = quantile.type)) + scale_x_continuous(breaks = quantile(x,
                c(0, quantilesx, 1), type = quantile.type), labels = round(quantile(x,
                c(0, quantilesx, 1), type = quantile.type), digits = 2),
                minor_breaks = NULL) + scale_y_continuous(breaks = quantile(y,
                c(0, quantilesy, 1), type = quantile.type), labels = round(quantile(y,
                c(0, quantilesy, 1), type = quantile.type), digits = 2),
                minor_breaks = NULL)
        }

    return(plot)
}
