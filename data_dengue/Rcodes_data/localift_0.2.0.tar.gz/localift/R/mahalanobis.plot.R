#' @import ggplot2
#' @import grDevices
#' @export
#' @title Mahalanobis Plot
#'
#' @description  Dispersion plot with the Mahalanobis partition ellipses.
#'
#' @details Dispersion plot of two random variables with the ellipses of the Mahalanobis partition given
#'          by the quantiles of a distances to a given point inside each level of a grouping factor.
#'
#' @param x A vector of data.
#' @param y A vector of data.
#' @param g Grouping factor.
#' @param g.color A vector with color names for the ellipses. It must present one color for each level of the grouping factor.
#' @param g.name Name of the grouping factor.
#' @param xlab Label of the x-axis.
#' @param ylab Label of the y-axis.
#' @param xlim Limits of the x-axis.
#' @param ylim Limits of the y-axis.
#' @param quantiles Quantiles of the Mahalanobis partition.
#' @param quantile.type Integer between 1 and 9 selecting one of the nine quantile algorithms of the \emph{quantile} function.
#' @param names Name of the partitions. Its length must equal \emph{length(quantiles) + 1}.
#' @param partition Logical. Whether the Mahalanobis ellipses are plotted.
#' @param rectangle Logical. Whether a rectangle is plotted around the data.
#' @param rectangle.color Color of the rectangle.
#' @param plot.title Title of the plot.
#' @param point Which point to calculate the distance from. Must be \emph{'zero'} or \emph{'mean'} for sample mean.
#' @param shape ggplot2 shape.
#' @param size ggplot2 size.
#' @param color Points point color.
#' @return \item{plot}{The dispersion plot.}
#' @return \item{quantiles}{The quantile of each observation of \emph{data}.}
#' @examples
#' attach(requirement)
#' mahalanobis.plot(C1,C2,xlim = c(0,10),ylim = c(0,10))
#' @references Simonis, A., Marcondes, D., Barrera, J. (2017) Feature Selection based on the Local Lift Dependence Scale. \emph{Submitted}

mahalanobis.plot <- function(x, y, g = NULL, g.color = "black", g.name = "Group",
    xlab = "x", ylab = "y", xlim = c(min(data[, 1]), max(data[, 1])),
    ylim = c(min(data[, 2]), max(data[, 2])), quantiles = c(1/3, 2/3),
    names = c("1 Tertile", "2 Tertile", "3 Tertile"), partition = TRUE,
    rectangle = TRUE, rectangle.color = "black", plot.title = " ",
    point = "zero", quantile.type = 7, shape = 16, size = 1.5, color = "black") {

    # Data
    data <- data.frame(x, y)

    # Test if the quantile sizes match
    quant.names(quantiles, names)

    # Graphical parameters
    titles <- theme(strip.text = element_text(size = 12), axis.text = element_text(size = 10,
        color = "black"), axis.title = element_text(size = 12), legend.text = element_text(size = 10),
        legend.title = element_text(size = 12))
    themes <- theme_linedraw()

    # If there is no grouping
    if (is.null(g)) {
        # Mahalanobis distance and partition
        dist <- mahalanobis(x = data, center = point(x = data, p = point),
            cov = cov(data))
        G <- cut(x = dist, breaks = quantile(x = dist, probs = c(0,
            quantiles, 1), type = quantile.type), labels = names,
            include.lowest = TRUE, right = TRUE)

        # What to plot
        if (!partition && !rectangle) {
            plot <- {
                ggplot(data, aes(x = data[, 1], y = data[, 2])) +
                  geom_point(shape = shape, size = size, color = color) +
                  themes + titles + xlab(xlab) + ylab(ylab) + scale_x_continuous(limits = xlim) +
                  scale_y_continuous(limits = ylim) + ggtitle(plot.title)
            }
        } else if (!partition && rectangle) {
            plot <- {
                ggplot(data, aes(x = data[, 1], y = data[, 2])) +
                  geom_point(shape = shape, size = size, color = color) +
                  themes + titles + xlab(xlab) + ylab(ylab) + scale_x_continuous(limits = xlim) +
                  scale_y_continuous(limits = ylim) + ggtitle(plot.title) +
                  geom_segment(x = xlim[1], y = ylim[2], xend = xlim[2],
                    yend = ylim[2], colour = rectangle.color) + geom_segment(x = xlim[1],
                  y = ylim[2], xend = xlim[1], yend = ylim[1], colour = rectangle.color) +
                  geom_segment(x = xlim[1], y = ylim[1], xend = xlim[2],
                    yend = ylim[1], colour = rectangle.color) + geom_segment(x = xlim[2],
                  y = ylim[1], xend = xlim[2], yend = ylim[2], colour = rectangle.color)
            }
        } else {
            # Draw ellipses
            cova <- solve(cov(data))
            quantiles.dist <- quantile(dist, probs = quantiles)
            p <- point(x = data, p = point)
            x <- NULL
            y <- NULL
            z <- NULL
            d <- transform(expand.grid(x = seq(xlim[1], xlim[2], length = 500),
                y = seq(ylim[1], ylim[2], length = 500)), z = cova[1,
                1] * (x - p[1])^2 + 2 * cova[1, 2] * (x - p[1]) *
                (y - p[2]) + cova[2, 2] * (y - p[2])^2)
            ellipses <- {
                ggplot(data, aes(x = data[, 1], y = data[, 2])) +
                  ggtitle(plot.title) + stat_contour(aes(x = x, y = y,
                  z = z), data = d, breaks = quantiles.dist, color = g.color)
            }
            if (!rectangle) {
                plot <- {
                  ellipses + geom_point(shape = shape, size = size,
                    color = color) + themes + titles + xlab(xlab) +
                    ylab(ylab) + scale_x_continuous(limits = xlim) +
                    scale_y_continuous(limits = ylim)
                }
            } else {
                plot <- {
                  ellipses + geom_point(shape = shape, size = size,
                    color = color) + themes + titles + xlab(xlab) +
                    ylab(ylab) + scale_x_continuous(limits = xlim) +
                    scale_y_continuous(limits = ylim) + geom_segment(x = xlim[1],
                    y = ylim[2], xend = xlim[2], yend = ylim[2], colour = rectangle.color) +
                    geom_segment(x = xlim[1], y = ylim[2], xend = xlim[1],
                      yend = ylim[1], colour = rectangle.color) +
                    geom_segment(x = xlim[1], y = ylim[1], xend = xlim[2],
                      yend = ylim[1], colour = rectangle.color) +
                    geom_segment(x = xlim[2], y = ylim[1], xend = xlim[2],
                      yend = ylim[2], colour = rectangle.color)
                }
            }
        }
    }

    # If there is grouping
    if (!is.null(g)) {
        if (length(g.color) != length(levels(g)))
            g.color <- rainbow(n = length(levels(g)))

        # What to plot
        if (!partition && !rectangle) {
            plot <- {
                ggplot(data, aes(x = data[, 1], y = data[, 2])) +
                  geom_point(shape = shape, size = size, color = color) +
                  themes + titles + xlab(xlab) + ylab(ylab) + scale_x_continuous(limits = xlim) +
                  scale_y_continuous(limits = ylim) + ggtitle(plot.title)
            }
            G <- NULL
        } else if (!partition && rectangle) {
            plot <- {
                ggplot(data, aes(x = data[, 1], y = data[, 2])) +
                  geom_point(shape = shape, size = size, color = color) +
                  themes + titles + xlab(xlab) + ylab(ylab) + scale_x_continuous(limits = xlim) +
                  scale_y_continuous(limits = ylim) + ggtitle(plot.title) +
                  geom_segment(x = xlim[1], y = ylim[2], xend = xlim[2],
                    yend = ylim[2], colour = rectangle.color) + geom_segment(x = xlim[1],
                  y = ylim[2], xend = xlim[1], yend = ylim[1], colour = rectangle.color) +
                  geom_segment(x = xlim[1], y = ylim[1], xend = xlim[2],
                    yend = ylim[1], colour = rectangle.color) + geom_segment(x = xlim[2],
                  y = ylim[1], xend = xlim[2], yend = ylim[2], colour = rectangle.color)
            }
            G <- NULL
        } else {
            ellipses <- ggplot(data, aes(x = data[, 1], y = data[,
                2], colour = g)) + ggtitle(plot.title)
            G <- vector()
            k <- 1

            for (f in levels(g)) {
                temp <- data[g == f, ]
                if (nrow(temp) < 2) {
                  k <- k + 1
                  warning(paste("sample size lesser than 2 for level",
                    f, "of", g.name))
                  next
                }
                # Draw ellipses and partition
                cova <- solve(cov(temp))
                dist <- mahalanobis(x = temp, center = point(x = temp,
                  p = point), cov = covp(temp))
                G[g == f] <- cut(x = dist, breaks = quantile(x = dist,
                  probs = c(0, quantiles, 1), type = quantile.type),
                  labels = names, include.lowest = TRUE, right = TRUE)
                quantiles.dist <- quantile(dist, probs = quantiles,
                  type = quantile.type)
                p <- point(x = data, p = point)
                x <- NULL
                y <- NULL
                z <- NULL
                d <- transform(expand.grid(x = seq(xlim[1], xlim[2],
                  length = 500), y = seq(ylim[1], ylim[2], length = 500)),
                  z = cova[1, 1] * (x - p[1])^2 + 2 * cova[1, 2] *
                    (x - p[1]) * (y - p[2]) + cova[2, 2] * (y - p[2])^2)
                ellipses <- {
                  ellipses + stat_contour(aes(x = x, y = y, z = z),
                    data = d, breaks = quantiles.dist, color = g.color[k])
                }
                k <- k + 1
            }
            if (!rectangle) {
                plot <- {
                  ellipses + geom_point(shape = shape, size = size) +
                    themes + titles + xlab(xlab) + ylab(ylab) + scale_x_continuous(limits = xlim) +
                    scale_y_continuous(limits = ylim) + scale_colour_manual(name = g.name,
                    values = g.color)
                }
            } else {
                plot <- {
                  ellipses + geom_point(shape = shape, size = size) +
                    themes + titles + xlab(xlab) + ylab(ylab) + scale_x_continuous(limits = xlim) +
                    scale_y_continuous(limits = ylim) + geom_segment(x = xlim[1],
                    y = ylim[2], xend = xlim[2], yend = ylim[2], colour = rectangle.color) +
                    geom_segment(x = xlim[1], y = ylim[2], xend = xlim[1],
                      yend = ylim[1], colour = rectangle.color) +
                    geom_segment(x = xlim[1], y = ylim[1], xend = xlim[2],
                      yend = ylim[1], colour = rectangle.color) +
                    geom_segment(x = xlim[2], y = ylim[1], xend = xlim[2],
                      yend = ylim[2], colour = rectangle.color) +
                    scale_colour_manual(name = g.name, values = g.color)
                }
            }
        }
    }
    p <- list(plot, G)
    names(p) <- c("plot", "quantiles")
    return(p)
}
