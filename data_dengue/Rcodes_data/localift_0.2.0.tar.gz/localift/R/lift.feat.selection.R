#' @import stats
#' @import utils
#' @export
#' @title Lift Featuring Selection Algorithm
#'
#' @description  Given two sets \emph{x} and \emph{y}, select the subsets of variables that are more dependent.
#'
#' @details Given two sets \emph{x} and \emph{y} of random variables, it returns the subsets \emph{x'} of \emph{x} and
#'          \emph{y'} of \emph{x} for which the Global Eta Coefficient,  or W-Local Eta Coefficient, or the Lift Function
#'          at a given point is the greatest in comparison to all the other combination of subsets of \emph{x} and \emph{y}.
#'
#' @param x Data frame in which each column is a sample of a random variable.
#' @param y Data frame in which each column is a sample of a random variable.
#' @param block.x Block factor in which x must be discretize within. The quantiles will be taken inside each block.
#' @param block.y Block factor in which y must be discretize within. The quantiles will be taken inside each block.
#' @param fix.x Number of the columns of x that must be considered in all iterations.
#' @param fix.y Number of the columns of y that must be considered in all iterations.
#' @param reach.x Vector with the sizes of the subsets of x that must be considered. Default is all the power set of x.
#' @param reach.y Vector with the sizes of the subsets of y that must be considered. Default is all the power set of y.
#' @param cost Cost function to be used. Must be \emph{"MI"} for Mutual Information, \emph{"eta"} for \emph{eta} on windows
#' or 'max' for the local max.
#' @param local If \emph{cost = 'max'}, must be the name of the category of \emph{y} which the maximum of the lift
#' must be searched for. Must be a level of \emph{y} or one of the labels in \emph{namesy}.
#' @param low.min If \emph{cost = 'max'}, must be an lower bound for the profile relative frequency, so that the algorithm
#' will search for the rows of the lift table with relative frequency greater than \emph{low.min}.
#' @param windows In what windows the eta coefficient must be calculated. Can be \emph{"all"} for all windows or \emph{"cat"} for the
#' windows that are given by a single category od \emph{U}.
#' @param trace Logical. Whether to return a data frame with the mutual information and the eta coefficient, along with the Lift Table, for every subset of \emph{y} and \emph{x}.
#' @param se Whether the standard error must be calculated for the lift table and the eta coefficients. If \emph{TRUE} the computational time
#' increases exponentially.
#' @param quantilesx Quantiles in which the variables \emph{x} must be partitioned. Must not contain \emph{0} nor \emph{1}.
#' @param quantilesy Quantiles in which the variables \emph{y} must be partitioned. Must not contain \emph{0} nor \emph{1}.
#' @param quantile.type An integer between 1 and 9 selecting one of the nine quantile algorithms of the \emph{quantile} function.
#' @param namesx Name of the partitions of \emph{x}. Its length must equal \emph{length(quantilesx) + 1}.
#' @param namesy Name of the partitions of \emph{y}. Its length must equal \emph{length(quantilesy) + 1}.
#' @param point Which point to calculate the distance from. Must be \emph{'zero'} or \emph{'mean'} for sample mean.
#' @param method Method that should be used to calculate the distance between the sample points
#'               and zero or the sample mean. Must be \emph{'mahalanobis'}, \emph{'euclidean'}, \emph{'maximum'},
#'               \emph{'manhattan'},\emph{'canberra'}, \emph{'binary'} or \emph{'minkowski'}.
#' @param p.minkowski The power of the Minkowski distance, if \emph{method = 'minkowski'}.
#' @param sample What information about the sample to display in parenthesis on the Lift Table. Must
#'               \emph{'size'} for sample size, \emph{'joint'} for relative frequency and \emph{'none'} for
#'               displaying nothing.
#' @param min.size Minimum sample size that can be considered. It will skip all combinations of the \emph{x}
#'                 and \emph{y} partitions in which the sample size is less than \emph{min.size}
#' @param right Logical, indicating if the quantile intervals should be closed on the right (and open on the left) or vice versa.
#' @return \item{lift}{The \link[localift]{LiftTable} of the selected features.}
#' @return \item{MI}{The Mutual information between the returned subsets.}
#' @return \item{Eta}{The dependence measures eta between the returned subsets.}
#' @return \item{EtaM}{The maximum eta dependence measure in windows of the returned x subset.}
#' @return \item{Window}{The window with maximum eta coefficient.}
#' @return \item{Max}{The maximum of the lift on the considered category of \emph{y}.}
#' @return \item{LevelMax}{The levels of \emph{x} for which the lift is \emph{max}.}
#' @return \item{subsetx}{The subset of \emph{x}}
#' @return \item{subsety}{The subset of \emph{y}}
#' @return \item{xquantile}{The quantile of each observation of \emph{x}.}
#' @return \item{yquantile}{The quantile of each observation of \emph{y}.}
#' @return \item{trace}{The table with the trace of the algorithm.}
#' @return \item{ltables}{The Lift Tables of each iteration.}
#' @examples
#' attach(requirement)
#' lift.feat.selection(SP,data.frame(C1,C2,C3,P1,P2),cost = "eta",trace = TRUE,local = "3 TertileY")
#'
#' @references Simonis, A., Marcondes, D., Barrera, J. (2017) Feature Selection based on the Local Lift Dependence Scale. \emph{Submitted}

lift.feat.selection <- function(y, x, block.x = NULL,block.y = NULL, fix.x = NULL, fix.y = NULL, reach.x = "all",
    reach.y = "all", cost = "eta",local = NULL,low.min = 0,windows = "all",trace = FALSE,se = FALSE, quantilesx = c(1/3,2/3),
    quantile.type = 7, namesx = c("1 TertileX","2 TertileX", "3 TertileX"), quantilesy = c(1/3,2/3),
    namesy = c("1 TertileY", "2 TertileY","3 TertileY"), method = "mahalanobis", p.minkowski = 1,sample = "se", point = "zero", min.size = 0,right = TRUE) {

    # Print
    cat("\n Feature Selection Algorithm Based on the Local Lift Dependence Scale \n")

    # Test if the quantile sizes match
    quant.names(quantilesx, namesx)
    quant.names(quantilesy, namesy)

    # Making all variables a data frame
    x <- data.frame(x)
    y <- data.frame(y)

    # Size of data frames
    sizedf(x,y)

    # If the windows must be searched
    if(cost == "eta")
      w = TRUE
    else
      w = FALSE

    # Reach of the algorithm
    if (reach.x[1] == "all")
        reach.x <- c(1:ncol(x))
    if (reach.y[1] == "all")
        reach.y <- c(1:ncol(y))

    # Set x and y powersets
    px <- getPowSet(c(1:ncol(x)))
    px <- px[unlist(lapply(px, function(x) length(x) %in% reach.x))]
    if (!is.null(fix.x))
        px <- px[unlist(lapply(px, function(x) fix.x %in% x))]
    limx <- length(px)
    if (is.null(block.x))
        block.x <- c(rep("1", nrow(x)))

    py <- getPowSet(c(1:ncol(y)))
    py <- py[unlist(lapply(py, function(x) length(x) %in% reach.y))]
    if (!is.null(fix.y))
        py <- py[unlist(lapply(py, function(x) fix.y %in% x))]
    limy <- length(py)
    if (is.null(block.y))
        block.y <- c(rep("1", nrow(y)))

    # Text
    if((limy * limx) > 128)
      cat("\n Sit tight and relax. It will take some time... \n")

    # Set the max of the cost function and data frames to trace the algorithm
    max <- -Inf
    level <- NA
    if (trace) {
      costTable <- data.frame(x = 0, y = 0,Window = 0, Eta = 0,MI = 0, max = 0,LevelMax = 0, size = 0)
      ltables <- list()
    }

    # Set progress bar
    pb <- txtProgressBar(min = 0, max = limy * limx, style = 3)
    k <- 1

    # Calculates the cost function for every powerset of x and y
    for (i in 1:limx) {
        # The x sets to be considered in the iteration
        setx <- px[[i]]
        datax <- data.frame(block.x, x[,setx])

        for (j in 1:limy) {

            # Update progress bar
            setTxtProgressBar(pb, k)

            # The y sets to be considered in the iteration
            sety <- py[[j]]
            datay <- data.frame(block.y, y[, sety])

            # Cleaning the missings
            clean <- cleanNA(datax, datay)
            datax_temp <- clean[[1]]
            datay <- clean[[2]]

            # Testing if the sample size is acceptable
            if (nrow(datax_temp) <= min.size){
                k <- k + 1
                next
            }

            # The lift table of the considered sets
            lift <- LiftTable(x = datax_temp[, -c(1)], y = datay[,-c(1)],se = se,w = w,windows = windows,local = local, block.x = datax_temp[, 1],
                              block.y = datay[,1],point.y = point, quantilesx = quantilesx,namesx = namesx,
                              quantilesy = quantilesy,namesy = namesy, point.x = point, method = method,low.min = low.min,
                              p.minkowski = p.minkowski, sample = sample,quantile.type = quantile.type,right = right)

            # Calculate cost function
            if (cost == "eta")
              C <- max(lift$eta$Eta)
            else if (cost == "MI")
                C <- lift$MI
            else if (cost == "max")
                C <- lift$max

            # Test if the cost is maximum
            if (C > max) {
              max <- C
              subsetx <- setx
              subsety <- sety
              level <- names(lift$max)
              liftF <- lift
            }

            # Trace the algorithm
            if (trace) {
                ltables[[k]] <- lift$ltable
                names(ltables)[k] <- paste(paste(names(x)[setx],collapse = " "),"and",
                                           paste(names(y)[sety],collapse = " "))
                if(cost == "eta")
                  costTable <- rbind.data.frame(costTable,data.frame("x" = as.character(paste(names(x)[setx],collapse = " ")),
                                                            "y" = as.character(paste(names(y)[sety],collapse = " ")),
                                                            "Window" = as.character(lift$eta$Window),
                                                            "Eta" = as.numeric(lift$eta$Eta),
                                                            "MI" = as.numeric(lift$MI),
                                                            "max" = as.numeric(lift$max),
                                                            "LevelMax" = names(lift$max),
                                                            "size" = nrow(data.frame(datax_temp))),stringsAsFactors = FALSE)
                else
                  costTable <- rbind.data.frame(costTable,data.frame("x" = as.character(paste(names(x)[setx],collapse = " ")),
                                                                     "y" = as.character(paste(names(y)[sety],collapse = " ")),
                                                                     "Window" = NA,
                                                                     "Eta" = NA,
                                                                     "MI" = as.numeric(lift$MI),
                                                                     "max" = as.numeric(lift$max),
                                                                     "LevelMax" = names(lift$max),
                                                                     "size" = nrow(data.frame(datax_temp))),stringsAsFactors = FALSE)

            }
            k <- k + 1
        }
    }

    # Retuning
    if(cost == "eta"){
      if(trace){
        costTable <- data.frame(costTable[, 1], costTable[,2], costTable[, 3],
                                as.numeric(costTable[,4]), as.numeric(costTable[, 5]),as.numeric(costTable[, 6]),costTable[, 7],as.numeric(costTable[, 8]))
        names(costTable) <- c("XSet", "YSet","Window", "Eta","MI", "Max","LevelMax","size")
        p <- list(liftF,liftF$MI, liftF$eta, liftF$eta$Eta[liftF$eta$Eta == max(liftF$eta$Eta)],as.character(liftF$eta$Window[liftF$eta$Eta == max(liftF$eta$Eta)]), liftF$max,names(liftF$max), names(x)[subsetx],names(y)[subsety], liftF$ltable, liftF$xquantile,
                  liftF$yquantile, costTable[-1, ], ltables)
        names(p) <- c("lift","MI", "Eta","EtaM","Window", "Max","LevelMax", "subsetx", "subsety","ltable", "xquantile", "yquantile", "trace",
                      "ltables")
      } else {
        p <- list(liftF,liftF$MI, liftF$eta, liftF$eta$Eta[liftF$eta$Eta == max(liftF$eta$Eta)],as.character(liftF$eta$Window[liftF$eta$Eta == max(liftF$eta$Eta)]), liftF$max,names(liftF$max), names(x)[subsetx],names(y)[subsety], liftF$ltable,
                  liftF$xquantile,liftF$yquantile)
        names(p) <- c("lift","MI","Eta", "EtaM","Window", "Max","LevelMax", "subsetx", "subsety","ltable", "xquantile", "yquantile")
      }
    }

    else{
      if(trace){
        costTable <- data.frame(costTable[, 1], costTable[,2], costTable[, 3],
                                as.numeric(costTable[,4]), as.numeric(costTable[, 5]),as.numeric(costTable[, 6]),costTable[, 7],as.numeric(costTable[, 8]))
        names(costTable) <- c("XSet", "YSet","Window", "Eta","MI", "Max","LevelMax","size")
        p <- list(liftF,liftF$MI, NA, NA,NA, liftF$max,names(liftF$max),names(x)[subsetx],names(y)[subsety], liftF$ltable, liftF$xquantile,
                  liftF$yquantile, costTable[-1, ], ltables)
        names(p) <- c("lift","MI", "Eta","EtaM","Window", "Max","LevelMax", "subsetx", "subsety","ltable", "xquantile", "yquantile", "trace",
                      "ltables")
      } else {
        p <- list(liftF,liftF$MI, NA, NA,NA, liftF$max,names(liftF$max), names(x)[subsetx],names(y)[subsety], liftF$ltable,
                  liftF$xquantile,liftF$yquantile)
        names(p) <- c("lift","MI","Eta", "EtaM","Window", "Max","LiftMax", "subsetx", "subsety","ltable", "xquantile", "yquantile")
      }
    }

    # Close progress bar
    close(pb)

    return(p)
}
