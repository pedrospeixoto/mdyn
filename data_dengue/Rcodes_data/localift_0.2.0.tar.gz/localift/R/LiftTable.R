#' @export
#' @title Lift Table
#'
#' @description  Lift Table between two groups of variables.
#'
#' @details If \emph{x} are \emph{y} are numeric vectors, it computes the Lift Table between
#'          the discrete random variables \emph{U} and \emph{V} determined from
#'          the sample quantiles of \emph{x} and \emph{y}, inside each level of the block variables. If \emph{x} or \emph{y}
#'          are numerical \emph{matrices}, then the Lift Table is computed from the discrete
#'          random variables \emph{U} and \emph{V} determined from the partition of \emph{(x,y)} by the selected distance method
#'          based on the sample quantiles, within each level of the block factors. If \emph{x} or \emph{y} are factor vectors,
#'          the Lift Function is calculated directly from \emph{x} and \emph{y}. If \emph{x} or \emph{y} contain numerical and factor variables
#'          then the discretization process is made by the quantile discretization of the sample distances from the given point, within
#'          each level of the factor and block variables.
#'
#'          If \emph{(U,V)} are discrete and \emph{(u,v)} is a category of \emph{(U,V)} then the Lift Function at such
#'          category is given by \eqn{L(u,v) = p(u,v) / (pU(u) * pV(v))} in which \emph{p} is
#'          the relative joint frequency of \emph{(U,V)} and \emph{pU} and \emph{pV}
#'          are the respective marginal relative frequencies. For more details see the References.
#'
#' @param table A contingency table without margins and with row and column names. Needed only if the factor variables are already tabulated.
#' @param x A numeric matrix, a factor vector or a numeric vector.
#' @param y A numeric matrix, a factor vector or a numeric vector.
#' @param se Whether the standard error must be calculated for the lift table and the eta coefficients.
#' @param local Must be the name of the category of \emph{y} in which the maximum of the lift must be searched for.
#' Must be a level of \emph{y} or one of the labels in \emph{namesy}. The \emph{default} is the first category of \emph{y}.
#' @param w Whether the \emph{eta} coefficient must be calculated for the \emph{windows} of the support of \emph{U}.
#' @param windows In what windows the eta coefficient must be calculated. Must be a list of vectors, in which each vector contain
#' the name of the categories of \emph{U}. Can be \emph{"all"} for all windows or \emph{"cat"} for the windows that are given by
#' a single category od \emph{U}
#' @param block.x Block factor in which x must be discretize within. The quantiles will be taken inside each block.
#' @param block.y Block factor in which y must be discretize within. The quantiles will be taken inside each block.
#' @param quantilesx Quantiles in which the variable \emph{x} must be partitioned. Must not contain \emph{0} nor \emph{1}.
#' @param quantilesy Quantiles in which the variables \emph{y} must be partitioned. Must not contain \emph{0} nor \emph{1}.
#' @param quantile.type An integer between 1 and 9 selecting one of the nine quantile algorithms of the \link[stats]{quantile} function.
#' @param namesx Name of the partitions of \emph{x}. Its length must equal \emph{length(quantilesx) + 1}.
#' @param namesy Name of the partitions of \emph{y}. Its length must equal \emph{length(quantilesy) + 1}.
#' @param point.x Which point to calculate the distances of x from. Must be \emph{'zero'}, \emph{'mean'} for sample mean or
#'                a vector with the dimension of x.
#' @param point.y Which point to calculate the distances of y from. Must be \emph{'zero'}, \emph{'mean'} for sample mean or
#'                a vector with the dimension of y.
#' @param method Method that should be used to calculate the distance. Must be \emph{'mahalanobis'}, \emph{'euclidean'}, \emph{'maximum'},
#'               \emph{'manhattan'},\emph{'canberra'}, \emph{'binary'} or \emph{'minkowski'}.
#' @param p.minkowski The power of the Minkowski distance, if \emph{method = 'minkowski'}.
#' @param low.min If \emph{cost = 'max'}, must be an lower bound for the profile relative frequency, so that the algorithm
#' will search for the rows of the lift table with relative frequency greater than \emph{low.min}.
#' @param sample What information about the sample to display in parenthesis on the Lift Table. Must be
#'               \emph{'size'} for sample size, \emph{'joint'} for relative frequency, \emph{'se'} for standard error and \emph{'none'} for
#'               displaying nothing.
#' @param right Logical, indicating if the quantile intervals should be closed on the right (and open on the left) or vice versa.
#' @param digits Integer indicating the number of significant digits (signif) to be used on the Lift Table.
#' @return \item{ltable}{The Lift Table. Rows are related to \emph{x} and columns to \emph{y}.}
#' @return \item{eta}{The dependence measures eta.}
#' @return \item{MI}{The normalized Mutual Information of the Lift Table.}
#' @return \item{max}{The maximum of the lift on the considered category of \emph{y}.}
#' @return \item{xquantile}{The quantile of each observation of \emph{x}.}
#' @return \item{yquantile}{The quantile of each observation of \emph{y}.}
#' @return \item{se}{The standard error for each lift value.}
#' @return \item{cov}{The covariance matrix of the lift function in lexicographical order.}
#' @examples
#' attach(requirement)
#' LiftTable(x = SP,y = data.frame(C3,P1))
#' LiftTable(x = data.frame(C1,C2,C3),y = data.frame(P1,P2))
#' LiftTable(x = data.frame(iris[,1:4]),y = iris$Species)
#' @references Simonis, A., Marcondes, D., Barrera, J. (2017) Feature Selection based on the Local Lift Dependence Scale. \emph{Submitted}

LiftTable <- function(table = NULL,x, y,se = TRUE,local = NULL,w = TRUE,windows = "all",block.x = 1,block.y = 1,quantilesx = c(1/3,2/3),
                      namesx = c("1 TertileX", "2 TertileX", "3 TertileX"),quantilesy = c(1/3,2/3),
                      namesy = c("1 TertileY", "2 TertileY", "3 TertileY"),quantile.type = 7,point.x = "zero",
                      point.y = "zero",method = "mahalanobis", p.minkowski = 1,low.min = 0,sample = "se",right = TRUE,
                      digits = 3) {
    # Sample information
    if(!se & sample == "se")
      sample <- "none"

    if(is.null(table)){
      # Test if the quantile sizes match
      quant.names(quantilesx, namesx)
      quant.names(quantilesy, namesy)

      # Making all variables a data frame
      x <- data.frame(x)
      y <- data.frame(y)

      # Size of data frames
      sizedf(x,y)

      # Partition factor variables
      f.x <- FALSE
      f.y <- FALSE
      if (length(Filter(is.factor, x)) > 0) {
        x <- data.frame(Discrete = as.factor(Reduce(function(...) paste(...,sep = "-"), Filter(is.factor, x))),
                        Filter(is.numeric,x))
        f.x <- TRUE
      }

      if (length(Filter(is.factor, y)) > 0) {
          y <- data.frame(Discrete = as.factor(Reduce(function(...) paste(...,sep = "-"), Filter(is.factor, y))),
                          Filter(is.numeric,y))
          f.y <- TRUE
      }

      # Partition x and y
      if (length(Filter(is.numeric, x)) > 0) {
          continuous <- Filter(is.numeric, x)
          if (f.x)
              Fx <- partition(continuous, discrete = x$Discrete, quantiles = quantilesx,names = namesx, type = quantile.type,
                              block = block.x,point = point.x, method = method, p.minkowski = p.minkowski,right = right)
          else Fx <- partition(continuous, discrete = NULL, quantiles = quantilesx,
              names = namesx, type = quantile.type, block = block.x,
              point = point.x, method = method, p.minkowski = p.minkowski,right = right)
      } else Fx <- x[, 1]

      if (length(Filter(is.numeric, y)) > 0) {
          continuous <- Filter(is.numeric, y)
          if (f.y)
              Fy <- partition(continuous, discrete = y$Discrete, quantiles = quantilesy,
                  names = namesy, type = quantile.type, block = block.y,
                  point = point.y, method = method, p.minkowski = p.minkowski,right = right)
          else Fy <- partition(continuous, discrete = NULL, quantiles = quantilesy,
              names = namesy, type = quantile.type, block = block.y,
              point = point.y, method = method, p.minkowski = p.minkowski,right = right)
      } else Fy <- y[, 1]

      # Sample size
      n <- length(Fx)

      # Joint probability
      joint <- prop.table(table(Fx,Fy))
      # Lift function
      if(se)
        lift <- se.lift(joint,length(Fx))
      else
        lift <- lift(Fx,Fy)
      # Sample information
      liftF <- sinfo(lift,sample,Fx,Fy,digits)
    }
    else{
      if(is.null(colnames(table)))
        colnames(table) <- c(1:ncol(table))
      if(is.null(rownames(table)))
        rownames(table) <- c(1:nrow(table))
      n <- sum(table)
      joint <- prop.table(table)
      if(se)
        lift <- se.lift(joint,n = sum(table))
      else
        lift <- liftT(table)
      liftF <- sinfoT(lift,sample,table,digits)
    }

    # Returning
    rownames(liftF) <- c(rownames(lift$lift),"FreqY")
    colnames(liftF) <- c(colnames(lift$lift),"FreqX")
    if(se)
      eta <- eta_se(joint = joint,w = w,windows = windows,n = n)
    else
      eta <- eta(joint = addmargins(joint),w = w,windows = windows)
    mutual <- mutual.info(joint)

    # Maximum of the lift
    tmp <- data.frame(liftF)
    colnames(tmp) <- colnames(liftF)
    rownames(tmp) <- rownames(liftF)
    tmp <- tmp[-nrow(tmp),]
    if(sample != "none"){
      if(is.null(local)){
        maxi <- max(as.numeric(sapply(strsplit(tmp[tmp[["FreqX"]] > low.min,1]," "), `[`, 1)))
        names(maxi) <- (rownames(tmp)[tmp[["FreqX"]] > low.min & as.numeric(sapply(strsplit(tmp[,1]," "), `[`, 1)) == maxi])[1]
      }
      else{
        maxi <- max(as.numeric(sapply(strsplit(tmp[[local]][tmp[["FreqX"]] > low.min]," "), `[`, 1)))
        names(maxi) <- (rownames(tmp)[tmp[["FreqX"]] > low.min & as.numeric(sapply(strsplit(tmp[[local]]," "), `[`, 1)) == maxi])[1]
      }
    }
    else{
      if(is.null(local)){
        maxi <- max(tmp[tmp[["FreqX"]] > low.min,1])
        names(maxi) <- (rownames(tmp)[tmp[["FreqX"]] > low.min & tmp[,1] == maxi])[1]
      }
      else{
        maxi <- max(tmp[[local]][tmp[["FreqX"]] > low.min])
        names(maxi) <- (rownames(tmp)[tmp[["FreqX"]] > low.min & tmp[[local]] == maxi])[1]
      }
    }

    if(is.null(table)){
      r <- list(liftF, eta, mutual, maxi, Fx, Fy,lift$se,lift$cov)
      names(r) <- c("ltable", "eta", "MI", "max", "xquantile", "yquantile","se","cov")
    }
    else{
      r <- list(liftF, eta, mutual, maxi,lift$se,lift$cov)
      names(r) <- c("ltable", "eta", "MI", "max","se","cov")
    }
    class(r) <- "LiftTable"
    return(r)
}
